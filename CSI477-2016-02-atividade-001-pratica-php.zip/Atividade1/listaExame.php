<?php

if (!isset($_SESSION)) session_start();
if (isset($_SESSION['UsuarioID']) && $_SESSION['UsuarioNivel'] == 3 ) {
  $conexao = mysqli_connect("localhost", "sisanalise","123456","analise");
  $id =  $_SESSION['UsuarioID'];
  if($conexao->connect_errno){
    echo "Falha";
  }else{
  //    echo "sucesso <br>";
  //  echo $conexao->host_info;
  }

  $sql = "SELECT procedimentos.nome, exames.data, procedimentos.preco FROM exames
  INNER JOIN procedimentos
  ON exames.paciente_id =$id and exames.procedimento_id = procedimentos.id  ORDER BY procedimentos.nome, exames.data desc";


  $resultado = $conexao->query($sql) or die($conexao->error);

}elseif(isset($_SESSION['UsuarioID']) && $_SESSION['UsuarioNivel'] == 1 ||$_SESSION['UsuarioNivel'] == 2 ){

  $conexao = mysqli_connect("localhost", "sisanalise","123456","analise");

  if($conexao->connect_errno){
    echo "Falha";
  }else{
  //    echo "sucesso <br>";
  //  echo $conexao->host_info;
  }

  $sql = "SELECT procedimentos.nome, exames.data, procedimentos.preco FROM exames
  INNER JOIN procedimentos
  ON exames.procedimento_id = procedimentos.id  ORDER BY procedimentos.nome, exames.data desc";


  $resultado = $conexao->query($sql) or die($conexao->error);
}else{

}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" type="text/css"
         href="bootstrap.css" />
  </head>
  <body>
    <div class="container">
      <h1> Sistema de Laboratorio </h1>
      <ul class="nav nav-tabs">
        <li ><a href="MenuInicial.php"> Visualizar Procedimento </a></li>
        <li class="active" ><a href="paciente.php"> Paciente </a></li>
        <li><a href="admin.php"> Administrador </a></li>
    </div>
    <div class="container">
         <div class="row">
           <div class="col-sm-8" style="background-color: white">
             <h1> Listar Exames </h1>
    <table class="table table-striped table-bordered" >
      <tr>
        <th> Exame</th>
        <th> Data </th>
        <th> Preco </th>
      </tr>
    <?php
        $total = 0;
        while($linha = $resultado->fetch_assoc()) {
            $total = $linha['preco'] + $total;
      ?>
      <tr>
        <td><?php echo $linha["nome"];?></td>
        <td><?php echo $linha["data"];?></td>
        <td><?php echo $linha["preco"];?></td>
      </tr>
    <?php } ?>

    </table>
    <h4 style="color:red">Preço Total: R$ <?php echo $total; ?></h4>
      <a class="btn btn-success " href="paciente.php">Voltar</a>
      <br><br>
  </div>
  </div>
  </div>

  </body>
</html>
