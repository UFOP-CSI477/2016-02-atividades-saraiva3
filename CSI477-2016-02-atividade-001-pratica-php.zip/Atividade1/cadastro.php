<?php

$conn = new mysqli("localhost", "sisanalise","123456","analise");


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$tipo = mysql_real_escape_string($_POST['operationType']);


if($tipo == 'paciente'){
  $nome = mysql_real_escape_string($_POST['nome']);
  $usuario = mysql_real_escape_string($_POST['login']);
  $senha = mysql_real_escape_string($_POST['senha']);

  $sql = "INSERT INTO pacientes (nome, login, senha)
  VALUES ('$nome', '$usuario', '$senha')";

  if ($conn->query($sql) === TRUE) {
       header("Location: CadastroPaciente.php");
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }

  $conn->close();
}
elseif($tipo == 'procedimento'){
  $nome = mysql_real_escape_string($_POST['nome']);
  $preco = mysql_real_escape_string($_POST['preco']);
  $sql1 = "SELECT id FROM usuarios WHERE tipo = 1";

  $sql = "INSERT INTO procedimentos (nome, preco,usuario_id)
  VALUES ('$nome', '$preco', '1')";

  if ($conn->query($sql) === TRUE) {

       header("Location: cadastroProcedimento.php");
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }

  $conn->close();



}elseif($tipo == 'exame'){


  $selected = $_POST['procedimento'];
  $data= mysql_real_escape_string($_POST['data']);
  session_start();

  $queryProcedimento = mysqli_query($conn, "SELECT id FROM procedimentos WHERE nome = $selected");
  $id_paciente = $_SESSION['UsuarioID'];
  $conn = new mysqli("localhost", "sisanalise","123456","analise");
  $sql = mysqli_query($conn, "SELECT id FROM procedimentos WHERE nome = '$selected'");
  $row = $sql->fetch_assoc();

  $sql = "INSERT INTO exames (paciente_id, procedimento_id, data)
  VALUES ('$id_paciente', '$row[id]', '$data')";

  if ($conn->query($sql) === TRUE) {
       header("Location: solicitarExames.php");
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }

  $conn->close();



}elseif($tipo == 'apagar'){
  $id = mysql_real_escape_string($_POST['id']);
  //QUERY QUE REMOVE
  $sql = "SELECT id FROM usuarios WHERE tipo = 1";

  if ($conn->query($sql) === TRUE) {
       header("Location: apagarExame.php");
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }

  $conn->close();



}

elseif($tipo == 'alterar'){

  $idExame = mysql_real_escape_string($_POST['idExame']);
  $procedimento = mysql_real_escape_string($_POST['procedimento']);
  $data = $_POST['data'];

  var_dump($idExame);
  //QUERY QUE ALTERA EXAME
  $sql = "UPDATE exames  SET data = '$data', procedimento_id=$procedimento  WHERE id = $idExame";

  if ($conn->query($sql) === TRUE) {
       header("Location: paciente.php");
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }

  $conn->close();



}elseif($tipo == 'alterarProcedimento'){
  $idProcedimento = mysql_real_escape_string($_POST['idProcedimento']);
  $nome = mysql_real_escape_string($_POST['nome']);
  $preco = $_POST['preco'];


  //QUERY QUE ALTERA EXAME
  $sql = "UPDATE procedimentos  SET preco = '$preco', nome= '$nome'  WHERE id = $idProcedimento";

  if ($conn->query($sql) === TRUE) {
       header("Location: admin.php");
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }

  $conn->close();



}

elseif($tipo == 'apagarExame'){
  $selected = $_POST['exame'];
  //QUERY QUE ALTERA EXAME
  $sql = "DELETE FROM exames WHERE $selected = id";

  if ($conn->query($sql) === TRUE) {
       header("Location: apagarExame.php");
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }

  $conn->close();



}

elseif($tipo == 'procedimentoRemove'){
  $selected = $_POST['removeProcedimento'];
  $conn = new mysqli("localhost", "sisanalise","123456","analise");
  $sql2 = mysqli_query($conn, "SELECT * FROM exames WHERE procedimento_id = $selected");


  if($sql2->fetch_assoc() === NULL){
    $sql = "DELETE FROM procedimentos WHERE $selected = id ";

    if ($conn->query($sql) === TRUE) {
         header("Location: admin.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

  }else{
    header("Location: admin.php?error=1");

  }

  $conn->close();



}
elseif($tipo == 'alterarPreco'){

    $idProcedimento = mysql_real_escape_string($_POST['idProcedimento']);
    $preco = $_POST['preco'];

    //QUERY QUE ALTERA EXAME
    $sql = "UPDATE procedimentos  SET preco = '$preco' WHERE id = $idProcedimento";

    if ($conn->query($sql) === TRUE) {
         header("Location: admin.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();






}

 ?>
