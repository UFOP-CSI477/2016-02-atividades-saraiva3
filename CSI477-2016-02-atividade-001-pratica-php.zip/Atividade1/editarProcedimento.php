<?php
if (!isset($_SESSION)) session_start();

$conn = new mysqli("localhost", "sisanalise","123456","analise");

if (isset($_SESSION['UsuarioID']) && $_SESSION['UsuarioNivel'] == 1 ) {
}
else{
   header("Location: admin.php"); exit;
}

$selected = $_POST['procedimento'];


$conn = new mysqli("localhost", "sisanalise","123456","analise");
$sql = mysqli_query($conn, "SELECT preco, id, nome FROM procedimentos WHERE id=$selected ");
$row = $sql->fetch_assoc();
$idProcedimento = $row['id'];
$nome = $row['nome'];
$preco = $row['preco'];

 ?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Alterar Exame</title>

    <link rel="stylesheet" type="text/css" href="bootstrap.css" />
</head>

<body>

<div class="container">
  <h1> Sistema de Laboratorio </h1>
  <ul class="nav nav-tabs">
    <li><a href="MenuInicial.php"> Visualizar Procedimento </a></li>
    <li class="active"><a href="paciente.php"> Paciente </a></li>
    <li><a href="admin.php"> Administrador </a></li>
  </div>
  <div class="container">
       <div class="row">
         <div class="col-sm-8" style="background-color: white">
           <form name="register" method="post" id="MyForm" action="cadastro.php" >
             <h1> Alterar Procedimento </h1>
             <div class="form-group">
                 <label for="nome" class="control-label col-sm-1">   Nome   </label>
                 <div class="col-sm-5">
                     <input type="text" class="form-control" name="nome" id="nome" value="<?=$nome  ?>">
                 </div>
                 <br>
             </div>
             <div class="form-group">
                 <label for="nome" class="control-label col-sm-1">   Preco   </label>
                 <div class="col-sm-5">
                     <input type="float" class="form-control" name="preco" id="preco" value="<?=$preco  ?>">
                 </div>
                 <br>
             </div>

       <input type="hidden" name="operationType" value="alterarProcedimento">
        <input type="hidden" name="idProcedimento"value="<?=$idProcedimento?>">
        <input type="submit" class="btn  btn-success" value="Aceitar">


        <a class="btn btn-default " href="alterarProcedimento.php">Voltar</a>
        </div>
        <br>

    </form>
  </div>
</div>
</div>
</body>

</html>
