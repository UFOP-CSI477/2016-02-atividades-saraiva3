<?php
$conexao = mysqli_connect("localhost", "sisanalise","123456","analise");

if($conexao->connect_errno){
  echo "Falha";
}

$sql = "SELECT nome, preco, usuario_id FROM procedimentos";
$resultado = $conexao->query($sql);

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>

    <link rel="stylesheet" type="text/css"
         href="bootstrap.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

  </head>
  <body>

    <div class="container">
      <h1> Sistema de Laboratorio </h1>
      <ul class="nav nav-tabs">
        <li class="active"><a href="MeuniInicial.php"> Visualizar Procedimento </a></li>
        <li><a href="paciente.php"> Paciente </a></li>
        <li><a href="admin.php"> Administrador </a></li>
    </div>
    <div class="container">
         <div class="row">
           <div class="col-sm-9" style="background-color: white">
             <h1> Procedimentos disponiveis: </h1>
    <table class="table table-bordered" >
      <tr>
        <th> Nome</th>
        <th> Preco </th>
      </tr>
    <?php
        while($linha = $resultado->fetch_assoc()) {
      ?>
      <tr>
        <td><?php echo $linha["nome"];?></td>
        <td>R$<?php echo $linha["preco"];?></td>
      </tr>
    <?php } ?>
    </table>
  </div>
</div>
</div>
  </body>
</html>
