<?php
if (!isset($_SESSION)) session_start();
if (isset($_SESSION['UsuarioID']) && $_SESSION['UsuarioNivel'] == 3 ) {
}
else{
   header("Location: paciente.php"); exit;
}

 ?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Alterar Exame</title>

    <link rel="stylesheet" type="text/css" href="bootstrap.css" />
</head>

<body>

<div class="container">
  <h1> Sistema de Laboratorio </h1>
  <ul class="nav nav-tabs">
    <li><a href="MenuInicial.php"> Visualizar Procedimento </a></li>
    <li class="active"><a href="paciente.php"> Paciente </a></li>
    <li><a href="admin.php"> Administrador </a></li>
  </div>
  <div class="container">
       <div class="row">
         <div class="col-sm-8" style="background-color: white">
           <form name="register" method="post" id="apagaExameForm" action="cadastro.php" >
             <h1> Escolha exame a ser apagado: </h1>
             <select name="exame">
               <?php
               $conn = new mysqli("localhost", "sisanalise","123456","analise");
               $id = $_SESSION['UsuarioID'] ;
               $sql = mysqli_query($conn, "SELECT data, procedimento_id, id FROM exames WHERE $id= paciente_id ");

               while ($row = $sql->fetch_assoc()){

                 $sql2 = mysqli_query($conn, "SELECT nome FROM procedimentos WHERE id =  $row[procedimento_id]");
                 $row2 = $sql2->fetch_assoc();
              echo "<option value=\"". $row['id']. "\">" ."Data: " . $row['data'] ." Exame: " . $row2['nome'] . "</option>";
         }
         ?>
       </select>
         <br><br>
       <input type="hidden" name="operationType" value="apagarExame">
        <input type="submit" class="btn  btn-success" value="Aceitar">
        <a class="btn btn-default " href="paciente.php">Voltar</a>
        </div>


    </form>
  </div>
    <br><br>
</div>
  <br><br>
</div>
  <br><br>
</body>

</html>
