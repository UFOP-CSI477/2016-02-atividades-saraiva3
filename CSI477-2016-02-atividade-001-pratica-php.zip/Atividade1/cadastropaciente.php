
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Cadastro Paciente</title>
      <script src="jquery-3.1.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap.css" />
    <script>

    function validateForm() {

     var x = document.forms["register"]["nome"].value;
     if (x == "") {
         alert("Nome está vazio");
         return false;
       }
       var x = document.forms["register"]["login"].value;
       if (x == "") {
           alert("Login está vazio");
           return false;
         }
     var y = document.forms["register"]["senha"].value;
       if(y == ""){
           alert("Senha está vazio");
           return false;
         }
         if(y.length < 8){
           alert("Senha deve ter 8 caracteres");
           return false;
         }

     }
    </script>
</head>

<body>
  <div class="container">
    <h1> Sistema de Laboratorio </h1>
    <ul class="nav nav-tabs">
      <li ><a href="#"> Visualizar Procedimento </a></li>
      <li class="active"><a href="paciente.php"> Paciente </a></li>
      <li><a href="admin.php"> Administrador </a></li>
  </div>
  <div class="container">
       <div class="row">
         <div class="col-sm-10" style="background-color: white">

    <form name="register" method="post" action="cadastro.php" onsubmit="return validateForm()" id="MyForm" >
        <h1 class="form">Cadastro Paciente</h1>
        <div class="form-group">
            <label for="nome" class="control-label col-sm-1"> Nome </label>
            <div class="col-sm-2">
                <input type="text" id="nome" class="form-control" name="nome">
            </div>
            <br>
        </div>
        <div class="form-group">
            <label for="login" class="control-label col-sm-1"> Login </label>
            <div class="col-sm-2">
                <input type="text" id="login" class="form-control" name="login">
            </div>
            <br>
        </div>
        <div class="form-group">
            <label for="senha" class="control-label col-sm-1"> Senha </label>
            <div class="col-sm-2">
                <input type="text" id ="senha" class="form-control" name="senha">
            </div>
            <br>
        </div>
        <br> <br>
        <div class=" btn-group col-sm-6">
          <input type="hidden" name="operationType" value="paciente" >
            <input type="submit" class="btn  btn-success" id ="aceitar" value="Aceitar">
            <input type="reset" class="btn  btn-danger " value="Limpar">

            <a class="btn btn-default " href="paciente.php">Voltar</a>
        </div>
        <br>

    </form>

  </div>
</div>
</div>
</body>

</html>
