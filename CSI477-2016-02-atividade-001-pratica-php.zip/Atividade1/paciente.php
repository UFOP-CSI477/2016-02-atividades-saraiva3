<?php
if (!isset($_SESSION)) session_start();
if (isset($_SESSION['UsuarioID']) && $_SESSION['UsuarioNivel'] == 3 ) {
    $acesso = 1;
}
else{
    $acesso = 0;

}

 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" type="text/css"
         href="bootstrap.css" />
         <script>
         function validateForm(id) {
           if(id>2){
             alert("Logado como paciente, somente admin e operador são permitidos.");
           }
         }
         </script>
  </head>
  <body>
    <div class="container">
      <h1> Sistema de Laboratorio </h1>
      <ul class="nav nav-tabs">
        <li><a href="MenuInicial.php"> Visualizar Procedimento </a></li>
        <li class="active"><a href="paciente.php"> Paciente </a></li>
        <li <?php echo " onclick=\"return validateForm(". $_SESSION['UsuarioNivel'] . ")\""?> ><a href="admin.php" > Administrador </a></li>
      </div>

    <div class="container">
         <div class="row">
           <div class="col-sm-8" style="background-color: white">
               <h1> Operacoes: </h1>
             <div class = "btn-group-vertical">
             <a href="login.php" class="btn btn-info" role="button" id="loginTeste">Login </a>
             <a href="cadastropaciente.php" class="btn btn-info" role="button">Cadastro novo paciente</a>
             <a href="solicitarExames.php" class="btn btn-info"  <?php if ($acesso == '0'){ ?> disabled <?php   } ?> role="button">Solicitar exame</a>
             <a href="apagarExame.php" class="btn btn-info"  <?php if ($acesso == '0'){ ?> disabled <?php   } ?> role="button">Apagar exame</a>
             <a href="alterarExame.php" class="btn btn-info"  <?php if ($acesso == '0'){ ?> disabled <?php   } ?> role="button">Alterar exame</a>
             <a href="listaExame.php" class="btn btn-info" role="button">Listar exames</a>
           </div>
           <br> <br>
           </div>
         </div>
         </div>
  </body>
</html>
