<?php

if (!empty($_POST) AND (empty($_POST['login']) OR empty($_POST['senha']))) {
     header("Location: MenuInicial.php"); exit;
 }


mysql_connect('localhost', 'sisanalise', '123456') or trigger_error(mysql_error());

 mysql_select_db('analise') or trigger_error(mysql_error());

 $usuario = mysql_real_escape_string($_POST['login']);
 $senha = mysql_real_escape_string($_POST['senha']);


 $sql = "SELECT login, senha, nome, id FROM pacientes WHERE login = '$usuario' AND senha= '$senha'";
 $sql2 =  "SELECT login, senha, nome, tipo FROM usuarios WHERE login = '$usuario' AND senha= '$senha'";
 $query = mysql_query($sql);
$query2 = mysql_query($sql2);
 if (mysql_num_rows($query) != 1 && mysql_num_rows($query2) != 1 ) {
     echo "Login inválido!"; exit;
 } else if(mysql_num_rows($query) == 1) {
      $resultado = mysql_fetch_assoc($query);
     if (!isset($_SESSION)) session_start();

     $_SESSION['UsuarioID'] = $resultado['id'];
     $_SESSION['UsuarioNome'] = $resultado['nome'];
     $_SESSION["UsuarioNivel"] = 3;
     header('location:paciente.php');
     exit;
 }else{
   $resultado = mysql_fetch_assoc($query2);
  if (!isset($_SESSION)) session_start();

  $_SESSION['UsuarioID'] = $resultado['nome'];
  $_SESSION['UsuarioNome'] = $resultado['nome'];
  $_SESSION["UsuarioNivel"] = $resultado['tipo'];
  header('location:admin.php');
  exit;
 }

?>
