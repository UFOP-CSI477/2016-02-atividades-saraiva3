<?php
if (!isset($_SESSION)) session_start();
if (isset($_SESSION['UsuarioID']) && $_SESSION['UsuarioNivel'] == 1  ) {
}
else{
   header("Location: admin.php"); exit;
}

 ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Cadastro Procedimento</title>

    <link rel="stylesheet" type="text/css" href="bootstrap.css" />
</head>

<body>
  <div class="container">
    <h1> Sistema de Laboratorio </h1>
    <ul class="nav nav-tabs">
      <li ><a href="MenuInicial.php"> Visualizar Procedimento </a></li>
      <li class="active"><a href="paciente.php"> Paciente </a></li>
      <li><a href="admin.php"> Administrador </a></li>
  </div>
  <div class="container">
       <div class="row">
         <div class="col-sm-10" style="background-color: white">

    <form name="register" method="post" action="cadastro.php" id="MyForm" >
        <h1 class="form">Escolha procedimento a ser removido:</h1>
        <label> Procedimentos: </label> <select name="removeProcedimento">
           <?php
           $conn = new mysqli("localhost", "sisanalise","123456","analise");
           $sql = mysqli_query($conn, "SELECT nome,id FROM procedimentos");
           while ($row = $sql->fetch_assoc()){
             echo "<option value=\"" . $row['id'] . "\">" . $row['nome'] . "</option>";
           }
           ?>

        <div class=" btn-group col-sm-6">
          <input type="hidden" name="operationType" value="procedimentoRemove">
            <input type="submit" class="btn  btn-success" value="Aceitar">


            <a class="btn btn-default " href="admin.php">Voltar</a>
        </div>
        <br>

    </form>

  </div>
</div>
</div>
</body>

</html>
