<?php
if (!isset($_SESSION)) session_start();
if (isset($_SESSION['UsuarioID']) && $_SESSION['UsuarioNivel'] == 1  ) {
}
else{
   header("Location: admin.php"); exit;
}

 ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Cadastro Procedimento</title>

    <link rel="stylesheet" type="text/css" href="bootstrap.css" />

    <script>
    function validateForm() {
     var x = document.forms["register"]["nome"].value;
     if (x == "") {
         alert("Nome está vazio");
         return false;
       }
     var y = document.forms["register"]["preco"].value;
       if(y == ""){
           alert("Preco está vazio");
           return false;
         }

     }

    </script>
</head>

<body>
  <div class="container">
    <h1> Sistema de Laboratorio </h1>
    <ul class="nav nav-tabs">
      <li ><a href="MenuInicial.php"> Visualizar Procedimento </a></li>
      <li class="active"><a href="paciente.php"> Paciente </a></li>
      <li><a href="admin.php"> Administrador </a></li>
  </div>
  <div class="container">
       <div class="row">
         <div class="col-sm-10" style="background-color: white">

    <form name="register" method="post" onsubmit= "return validateForm()" action="cadastro.php" id="register" >
        <h1 class="form">Cadastro Procedimento: </h1>
        <div class="form-group">
            <label for="nome" class="control-label col-sm-1"> Nome: </label>
            <div class="col-sm-2">
                <input type="text" id="nome" class="form-control" name="nome">
            </div>
            <br>
        </div>
        <div class="form-group">
            <label for="login" class="control-label col-sm-1"> Preco: </label>
            <div class="col-sm-2">
                <input type="float" id="preco" class="form-control" name="preco">
            </div>
            <br>
        </div>

        <div class=" btn-group col-sm-6">
          <input type="hidden" name="operationType" value="procedimento">
            <input type="submit" class="btn  btn-success" value="Aceitar">
            <input type="reset" class="btn  btn-danger " value="Limpar">

            <a class="btn btn-default " href="admin.php">Voltar</a>
        </div>
        <br>

    </form>

  </div>
</div>
</div>
</body>

</html>
