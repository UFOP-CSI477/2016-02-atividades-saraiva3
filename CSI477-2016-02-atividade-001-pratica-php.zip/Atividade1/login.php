<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" type="text/css"
         href="bootstrap.css" />
    <script src="jquery-3.1.1.js"></script>

   <script>
   function validateForm() {
    var x = document.forms["formlogin"]["nome"].value;
    if (x == "") {
        alert("Login está vazio");
        return false;
      }
    var y = document.forms["formlogin"]["senha"].value;
      if(y == ""){
          alert("Senha está vazio");
          return false;
        }

    }
   </script>
  </head>
  <body>
    <div class="container">
      <h1> Sistema de Laboratorio </h1>
      <ul class="nav nav-tabs">
        <li ><a href="#"> Visualizar Procedimento </a></li>
        <li class="active"><a href="paciente.php"> Paciente </a></li>
        <li><a href="admin.php"> Administrador </a></li>
    </div>
    <div class="container">
         <div class="row">
           <div class="col-sm-8" style="background-color: white">
    <form method="post" action="ope.php" id="formlogin" onsubmit="return validateForm()"  name="formlogin" >
      <h1 class="form">Logar no sistema: </h1>
      <div class="form-group">
          <label for="nome" class="control-label col-sm-1"> Login: </label>
          <div class="col-sm-4">
              <input type="text" id="nome" class="form-control" name="login">
          </div>
          <br>
      </div>
      <div class="form-group">
          <label for="login" class="control-label col-sm-1"> Senha: </label>
          <div class="col-sm-4">
              <input type="password" id="senha" class="form-control" name="senha">
          </div>
          <br>
      </div>
      <br> <br>
      <div class=" btn-group col-sm-6">
        <input type="hidden" name="operationType" value="paciente">
          <input type="submit" class="btn  btn-success" value="Logar">
          <input type="reset" class="btn  btn-danger " value="Limpar">
          <a class="btn btn-default " href="paciente.php">Voltar</a>
      </div>
      <br><br>
</form>
</div>
</div>
</div>
  </body>
</html>
