<?php
if (!isset($_SESSION)) session_start();

$conn = new mysqli("localhost", "sisanalise","123456","analise");

if (isset($_SESSION['UsuarioID']) && $_SESSION['UsuarioNivel'] == 3 ) {
}
else{
   header("Location: paciente.php"); exit;
}

$selected = $_POST['exame'];

$conn = new mysqli("localhost", "sisanalise","123456","analise");
$id = $_SESSION['UsuarioID'];
$sql = mysqli_query($conn, "SELECT data, procedimento_id, id  FROM exames WHERE  id= $selected");
$row = $sql->fetch_assoc();
$data = $row['data'];

$idExame = $row['id'];
 ?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Alterar Exame</title>

    <link rel="stylesheet" type="text/css" href="bootstrap.css" />
</head>

<body>

<div class="container">
  <h1> Sistema de Laboratorio </h1>
  <ul class="nav nav-tabs">
    <li><a href="MenuInicial.php"> Visualizar Procedimento </a></li>
    <li class="active"><a href="paciente.php"> Paciente </a></li>
    <li><a href="admin.php"> Administrador </a></li>
  </div>
  <div class="container">
       <div class="row">
         <div class="col-sm-8" style="background-color: white">
           <form name="register" method="post" id="MyForm" action="cadastro.php" >
             <h1> Alterar Exame </h1>
             <div class="form-group">
                 <label for="nome" class="control-label col-sm-1">   Data Atual   </label>
                 <div class="col-sm-5">
                     <input type="date" class="form-control" name="data" value="<?=$data  ?>">
                 </div>
                 <br>
             </div>
            <label> Procedimentos </label> <select name="procedimento">
               <?php
               $sql = mysqli_query($conn, "SELECT nome, id FROM procedimentos");
               while ($row = $sql->fetch_assoc()){
                 echo "<option value=\"". $row['id'] ."\">" . $row['nome'] . "</option>";
         }
         ?>
       </select>
       <input type="hidden" name="operationType" value="alterar">
        <input type="hidden" name="idExame"value="<?=$idExame?>">
        <input type="submit" class="btn  btn-success" value="Aceitar">
        <input type="reset" class="btn  btn-danger " value="Limpar">

        <a class="btn btn-default " href="paciente.php">Voltar</a>
        </div>
        <br>

    </form>
  </div>
</div>
</div>
</body>

</html>
