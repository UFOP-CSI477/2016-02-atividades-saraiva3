<?php
if (!isset($_SESSION)) session_start();
if (isset($_SESSION['UsuarioID']) && $_SESSION['UsuarioNivel'] == 3 ) {
}
else{
 echo '<script type="text/javascript">    validadeForm();      </script>';
   header("Location: paciente.php"); exit;
}

 ?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Cadastro Procedimento</title>
  <script src="jquery-3.1.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap.css" />
    <script>


    </script>
</head>

<body>

<div class="container">
  <h1> Sistema de Laboratorio </h1>
  <ul class="nav nav-tabs">
    <li><a href="MenuInicial.php"> Visualizar Procedimento </a></li>
    <li class="active"><a href="paciente.php"> Paciente </a></li>
    <li><a href="admin.php"> Administrador </a></li>
  </div>
  <div class="container">
       <div class="row">
         <div class="col-sm-8" style="background-color: white">
           <form name="register" method="post" id="MyForm" action="cadastro.php" >
             <h1> Marcar Exame </h1>
            <label> Procedimentos: </label> <select name="procedimento">
               <?php
               $conn = new mysqli("localhost", "sisanalise","123456","analise");
               $sql = mysqli_query($conn, "SELECT nome FROM procedimentos");
               while ($row = $sql->fetch_assoc()){
                 echo "<option value=\"" . $row['nome'] . "\">" . $row['nome'] . "</option>";
         }
         ?>
       </select>
        <div class="form-group">
            <label for="nome" class="control-label col-sm-1"> Data:        </label>
            <div class="col-sm-5">
                <input type="date" class="form-control" name="data">
            </div>
            <br><br>
        </div>
        <div class="form-group">
        <div class=" btn-group col-sm-6">
        <input type="hidden" name="operationType" value="exame">
        <input type="submit" class="btn  btn-success" value="Aceitar">
        <input type="reset" class="btn  btn-danger " value="Limpar">

        <a class="btn btn-default " href="paciente.php">Voltar</a>
        </div>
        <br><br>

    </form>
  </div>
</div>
</div>
</body>

</html>
