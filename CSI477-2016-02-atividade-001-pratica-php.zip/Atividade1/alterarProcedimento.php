<?php
if (!isset($_SESSION)) session_start();
if (isset($_SESSION['UsuarioID']) && $_SESSION['UsuarioNivel'] == 1 ) {
}
else{
   header("Location: admin.php"); exit;
}

 ?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Alterar Exame</title>

    <link rel="stylesheet" type="text/css" href="bootstrap.css" />
</head>

<body>

<div class="container">
  <h1> Sistema de Laboratorio </h1>
  <ul class="nav nav-tabs">
    <li><a href="MenuInicial.php"> Visualizar Procedimento </a></li>
    <li ><a href="paciente.php"> Paciente </a></li>
    <li class="active" ><a href="admin.php"> Administrador </a></li>
  </div>
  <div class="container">
       <div class="row">
         <div class="col-sm-8" style="background-color: white">
           <form name="register" method="post" id="alterarExame" action="editarPreco.php" >
             <h1> Escolha procedimento a ser alterado:  </h1>
             <select name="procedimento">
               <?php
               $conn = new mysqli("localhost", "sisanalise","123456","analise");
               $sql = mysqli_query($conn, "SELECT preco, id, nome FROM procedimentos ");
               while ($row = $sql->fetch_assoc()){

              echo "<option value=\"". $row['id']. "\">" ."Nome : " . $row['nome'] ." - Preco:R$ " . $row['preco'] . "</option>";
         }
         ?>
       </select>
<br><br>
        <input type="submit" class="btn  btn-success" value="Aceitar">
        <a class="btn btn-default " href="admin.php">Voltar</a>
        </div>

    </form>
    <br><br>

  </div>
</div>
</div>
<br><br>

</body>

</html>
