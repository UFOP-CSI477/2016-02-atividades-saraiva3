<?php
if (!isset($_SESSION)) session_start();



if (isset($_SESSION['UsuarioID']) ) {
  if ($_SESSION['UsuarioNivel'] == 1){
    $acesso =1;
   }

   else if ($_SESSION['UsuarioNivel'] == 2){
     $acesso = 0;
    }
    else {

     header('location:paciente.php');
    }
}else{
    header('location:paciente.php');
}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" type="text/css"
         href="bootstrap.css" />

  </head>

  <body>
    <?php if(isset($_GET['error'] )){ if($_GET['error'] == 1){ ?><script> alert("Não pode ser removido.")</script> <?php }} ?>
    <div class="container">
      <h1> Sistema de Laboratorio </h1>
      <ul class="nav nav-tabs">
        <li ><a href="MenuInicial.php"> Visualizar Procedimento </a></li>
        <li><a href="paciente.php"> Paciente </a></li>
        <li class="active"><a href="admin.php"> Administrador </a></li>
    </div>

    <div class="container">
         <div class="row">
           <div class="col-sm-8" style="background-color: white">
             <h1> Operacoes </h1>
             <div class = "btn-group-vertical">

               <a href="cadastroProcedimento.php" class="btn btn-info" <?php if ($acesso == '0'){ ?> disabled <?php   } ?>role="button">Cadastro procedimento </a>
               <a href="alterarProcedimento.php" class="btn btn-info"<?php if ($acesso == '0'){ ?> disabled <?php   } ?> role="button">Atualizar procedimento</a>
               <a href="removerProcedimento.php" class="btn btn-info" <?php if ($acesso == '0'){ ?> disabled <?php   } ?> role="button">Remover procedimento</a>
               <a href="listaExame.php" id = "lista" class="btn btn-info" role="button">Lista exames </a>
               <a href="alterarPreco.php" id = "preco" class="btn btn-info" role="button">Alterar preco </a>
           </div>
           <br><br>

         </div>
         </div>


         </div>

  </body>
</html>
